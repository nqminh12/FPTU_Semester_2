/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author trinh
 */
public class Car {
    

    public Car(String name, double price) {
        
    }
    public String getName() {
        return "";
    }

    public double getPrice() {
        return 0;
    }

    public void setPrice(double price) {
    }
}
