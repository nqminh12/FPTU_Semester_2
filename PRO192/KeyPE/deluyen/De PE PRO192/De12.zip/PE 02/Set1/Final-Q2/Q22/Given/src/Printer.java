
public class Printer {

    double price;
    String name;

    public Printer() {
    }

    public Printer(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    //add and complete you other methods (if needed) here   
}
