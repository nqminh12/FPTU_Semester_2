
import java.util.List;


/**
 *
 * @author alias
 */
public class MyPrinter{

    
}
