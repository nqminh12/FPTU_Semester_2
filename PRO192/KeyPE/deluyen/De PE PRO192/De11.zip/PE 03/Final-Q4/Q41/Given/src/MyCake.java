
import java.util.ArrayList;
//Your job is to complete this class 
//this class will implement IFlower interface
public class MyCake implements ICake
{

    //write the definition of method getHighestPrice here 
    @Override
    public String getHighestPrice(ArrayList a) {
         String out = "";         
         //your codes goes here
         return out;
    }
 
   
    //write the definition of method count here 
    @Override
    public int count(ArrayList a) {
        int out = -1;
        //your codes goes here        
        return out;
    }
    
    //add and complete you other methods (if needed) here   
     
}
