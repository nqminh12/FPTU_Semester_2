//your job is to complete this class
public class Cake{   
    public Cake(String name, double price, double itax) { 
         //your code goes here      
    }
    //add and complete you other methods (if needed) here   
 
}
