public class ReservationCode {
   

    public ReservationCode(String code, String customerName) {
        
    }

    boolean getCode() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

   

}
