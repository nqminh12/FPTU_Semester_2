
public class Employee {
  
     
    public Employee() {
    }
    
    public Employee(String name, double salary) {
       
    }

    
    
}
