
public class Seller extends Employee {  

   
    public Seller() {
      throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    public Seller(String name, double revenue, double salary) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    public double getSalary() {
       throw new UnsupportedOperationException("Remove this line and implement your code here!");
    } 
    
    

    
}
