import java.util.*;
//Your task is to complete this class 
public class MyBook implements IBook {    
    //write the definition of method f1 here 
    @Override
    public String f1(ArrayList<Book> a) {
        throw new UnsupportedOperationException(
                "Remove this line and implement your code here!");
    }  
    
    //write the definition of method f2 here 
    @Override
    public int f2(ArrayList<Book> a, int price) { 
       throw new UnsupportedOperationException(
                "Remove this line and implement your code here!");
    }    
    //add and complete you other methods (if needed) here   
     
}
