//your task is to complete this class
public class Book {  
    public Book(String name, int price) {
         throw new UnsupportedOperationException(
                "Remove this line and implement your code here!");
    }  
    //add and complete you other methods (if needed) here   

}
